</br></br></br></br></br></br>

<center>
<p style="font-family:Sulphur Point; font-size:7em;">Rising Waters</p>  
<p style="font-family:Sulphur Point; font-size:3em;">Game Design Document</p>
</center>

</br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br>  

__by:__  
Afonso Lage - 21901381  
André Santos - 21901767  
Rui Vilar - 21902960

<div style="page-break-after: always;"></div>

## __Table of Contents__

- [__Table of Contents__](#table-of-contents)
- [__Movie Synopsis__](#movie-synopsis)
- [__History__](#history)
- [__Mechanics__](#mechanics)
  - [__First Half of the game__](#first-half-of-the-game)
  - [__Second Half of the game__](#second-half-of-the-game)
- [__Game Objectives__](#game-objectives)
- [__Game "World"__](#game-%22world%22)
- [__Game Agents__](#game-agents)
- [__Means of Storytelling__](#means-of-storytelling)

<div style="page-break-after: always;"></div>

## __Movie Synopsis__

A poor artist and a young rich woman meet and fall in love while in the Titanic. Although she is married to a soon to be successful business owner, she defies her family and friends in search of the one true love.

## __History__

You're **Arthur**, one of the few reporters who were lucky enough to get selected to be able to get on board of the Titanic on its inaugural trip. You were tasked to write an article about what's like to be on board of the world's fanciest ship.  
</br>
You get to your room and start to rest when suddenly you feel the ship shaking and you hear the alarms. You go gather your stuff and go out of the room to see what's going on when out of nowhere you see water flooding the hallway so you start to do the only thing you can think of...you run!

## __Mechanics__

### __First Half of the game__

- __Jump__ -> [W], [Up Key] or [Space];
- __Crouch__ -> [S] or [Down Key]  
</br>
In this part of the game the player is running through the hallways in order to escape the water. He has to jump or crouch to avoid the obstacles he faces otherwise he will slow down and get consumed by the wave of water behind him. As the player goes up the stairs onto the next hallway the ship's leaning gets progressively wider.
  
### __Second Half of the game__

- __Move Left or Right__ -> [A] or [D], [Left Key] or [Right Key] ;  
</br>
In this second half of the game the player is on top of a table that is floating on the water. The player has to dodge falling debris and avoid getting stuck in order to escape the ship alive.

## __Game Objectives__  

- __First Half__ -> Escape from the water while avoiding various obstacles;
- __Second Half__ -> Use the rising water to get to the other side of the ship without getting hit by de debris;

## __Game "World"__

During the **first half** of the game Arthur is running through hallways trying to escape the water that is flooding the ship. Then he gets hit with a table in the face and is knocked unconscious.
</br>
During the **second half** he wakes up on top of a table floating on the water, the ship now is fully sideways and the water is quickly rising. Arthur uses a stick he finds by his side to navigate through ship avoiding debris and getting stuck.

## __Game Agents__

- __Arthur__ -> He is our main character and the player controls him.
  
- __Various types of debris__ -> These are all types of objects that can fall on the player and slow him down. For example, chairs, lamps...etc.
  
- __Obstacles__ -> Which the player has to jump over or slide under so he doesn't hit them and slow down.

- __The Water__ -> The player has to avoid getting overtaken by the water at all costs otherwise he will drown.
  
- __The table and Stick__ -> This is what the player uses to be able to be on top of the water and get to the other side of the ship.

## __Means of Storytelling__

In this game we will use cutscenes for when the player isn't controlling our main character. For example, when Arthur is going up floors, at the beginning and at the end of the game or when Arthur gets hit by a door.
