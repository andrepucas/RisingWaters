# Planeamento de Projeto

|Semana    |Afonso                 |André                  |Rui                    |
|:--------:|:---------------------:|:---------------------:|:---------------------:|
|00        |Resoluções             |Resoluções             |Resoluções             |
|01        |Layout de níveis       |Arte Corredores        |Sistema de Câmara      |
|02        |""                     |Arte Personagem        |Sistema de Movimentos  |
|03        |Sistema de pontuação   |""                     |Obstáculos             |
|04        |Definição de Assets    |""                     |""                     |
|05        |Som e música           |Água C1                |Sistema de Câmara 2    |
|06        |         ""            |Água C2                |""                     |
|07        |Testing                |Objetos                |Programação Água       |
|08 (Slice)|Balanceamento          |Finishers              |""                     |
|09        |Definição de menus     |Menus                  |Botões                 |
|10        |Testing                |""                     |""                     |
|11        |Balanceamento          |Logótipo               |Fix last bugs          |
|12        |Testing                |Finishers              |""                     |
|13 (Final)|Balanceamento          |""                     |Finishers              |

</br>

**Nota:** Existirá entre ajuda em algumas tarefas.
