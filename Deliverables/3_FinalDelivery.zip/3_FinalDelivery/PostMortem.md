# Post Mortem
## Rising Waters

### O que correu bem?
O que correu bem e até nos salvou algumas vezes foi a nossa utilização do git.
 Algumas vezes algo correu bem e nós utilizamos o git de forma correta e conseguimos
 "salvar" o projeto mais que uma vez.

### O que correu mal?
No nosso projeto o que correu mal foi a parte de programar o "Arcade Mode",
 foram surgindo vários problemas e acabamos por ficar um pouco sobrecarregados
  mais para o final.

### O que podíamos ter feito melhor?
Nós se calhar podíamos ter dedicado mais atenção à parte da programação quando
 começaram a surgir os problemas mas estávamos muito focados no que tínhamos que
 fazer individualmente. Para além disso, devíamos ter cumprido o planeamento de 
 projeto de uma forma mais rigorosa.