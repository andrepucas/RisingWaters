# Planeamento de Projeto

|Semana    |Afonso                 |André                  |Rui                    |
|:--------:|:---------------------:|:---------------------:|:---------------------:|
|00        |Resoluções             |Resoluções             |Resoluções             |
|01        |Layout de níveis       |Arte Corredores        |Sistema de Câmara      |
|02        |""                     |Arte Personagem        |Sistema de Movimentos  |
|03        |Sistema de pontuação   |""                     |Obstáculos             |
|04        |Definição de Assets    |""                     |""                     |
|05        |Som e música           |Água C1                |Sistema de Câmara 2    |
|06        |         ""            |Água C2                |""                     |
|07        |Testing                |Objetos                |Programação Água       |
|08 (Slice)|Balanceamento          |Finishers              |""                     |
|09        |Som e música           |Arte Personagem        |Botões                 |
|10        |Layout do Menu         |Arte Água              |""                     |
|11        |Balanceamento          |Obstáculos             |Fix last bugs          |
|12        |Testing                |Finishes               |""                     |
|13 (Final)|Balanceamento          |Logótipo               |Finishes               |

</br>

**Nota:** Existirá entre ajuda em algumas tarefas.
